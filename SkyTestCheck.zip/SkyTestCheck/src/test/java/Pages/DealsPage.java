/*This is the Deals Page Page Object Model (POM).
 * 
 * This captures all the elements (required) and their associated methods
 * The class is instantiated from the PageNavigator class, and the constructor is created.
 * 
 * The methods available are to
 * 1. validateDelsPage() - this has a counter based on all menu available to confirm the page
 * 2. clickTVDeal(), clickBbTvDeal(), clickMobileDeal() - actions based on web elements to confirm menu
 *  
 */

package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DealsPage{

	public WebDriver driver = null;
	
	private By deals_tv_button = By.xpath("//body/main[@id='root']/div[1]/div[1]/div[1]/div[1]/button[1]");
	private By deals_tv_bb_button = By.xpath("//body/main[@id='root']/div[1]/div[1]/div[1]/div[1]/button[2]");
	private By deals_mobile_button = By.xpath("//body/main[@id='root']/div[1]/div[1]/div[1]/div[1]/button[3]");
		
	private By tv_deal1 = By.xpath("//p[contains(text(),'Ultimate TV')]");
	private By tv_deal2 = By.xpath("//p[contains(text(),'Sky TV & Sky Sports')]");
	private By tv_deal3 = By.xpath("//p[contains(text(),'Sky TV, Netflix & Cinema')]");
	private By tv_deal4 = By.xpath("//p[contains(text(),'The Full House')]");
	private By tv_deal5 = By.xpath("//p[contains(text(),'Sky TV & Kids')]");
	private By tv_deal6 = By.xpath("//p[contains(text(),'Build your own package')]");	
	
	private By bb_deal1 = By.xpath("//p[contains(text(),'Superfast TV Deal')]");
	private By bb_deal2 = By.xpath("//p[contains(text(),'Ultrafast TV Deal')]");
	private By bb_deal3 = By.xpath("//p[contains(text(),'Sky TV, Cinema & Superfast Broadband')]");
	private By bb_deal4 = By.xpath("//body/main[@id='root']/section[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/p[1]");
	private By bb_deal5 = By.xpath("//p[contains(text(),'Sky TV, Sports, Cinema & Broadband')]");
	private By bb_deal6 = By.xpath("//p[contains(text(),'Build your own package')]");
	
	private By mob_deal1 = By.xpath(" //p[contains(text(),'Bold Galaxy S20 FE 5G')]");
	private By mob_deal2 = By.xpath("//p[contains(text(),'Stunning iPhone 11')]");
	private By mob_deal3 = By.xpath("//p[contains(text(),'Brilliant iPhone 12')]");
	public int tab_count=0;
	
	public DealsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickTvDeal() {
		System.out.println("Entered TV Deal with value  ");
		driver.findElement(deals_tv_button).click();
		if (driver.findElement(deals_tv_button).isEnabled()) {
			driver.findElement(tv_deal1).isDisplayed();
			driver.findElement(tv_deal2).isDisplayed();
			driver.findElement(tv_deal3).isDisplayed();
			driver.findElement(tv_deal4).isDisplayed();
			driver.findElement(tv_deal5).isDisplayed();
			driver.findElement(tv_deal6).isDisplayed();
			}		
	}
	
	public void clickBbTvDeal() {
		driver.findElement(deals_tv_bb_button).click();
		if (driver.findElement(deals_tv_bb_button).isEnabled()) {
			driver.findElement(bb_deal1).isDisplayed();
			driver.findElement(bb_deal2).isDisplayed();
			driver.findElement(bb_deal3).isDisplayed();
			driver.findElement(bb_deal4).isDisplayed();
			driver.findElement(bb_deal5).isDisplayed();
			driver.findElement(bb_deal6).isDisplayed();
			}		
	}
	public void clickMobileDeal() {
		driver.findElement(deals_mobile_button).click();
		if (driver.findElement(deals_mobile_button).isEnabled()) {
			driver.findElement(mob_deal1).isDisplayed();
			driver.findElement(mob_deal2).isDisplayed();
			driver.findElement(mob_deal3).isDisplayed();
		}		
	}
	
	public int validateDealsPage() {
		if (driver.findElement(deals_tv_button).isDisplayed()){
			tab_count++;
		}
		if (driver.findElement(deals_tv_bb_button).isDisplayed()){
			tab_count++;
		}
		if (driver.findElement(deals_mobile_button).isDisplayed()){
			tab_count++;
		}
		return(tab_count);
	}
}